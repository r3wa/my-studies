package br.com.experian.pbd.plugin.file;

import java.util.List;

public interface FileCreator {

	void createFile(List<String> namesOfClasse);

}
